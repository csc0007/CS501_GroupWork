package com.example.flashcard

//import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.flashcard.databinding.ActivityFlashcardBinding


class FlashcardActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFlashcardBinding

    private val flashcardViewModel: FlashcardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFlashcardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.generateButton.setOnClickListener {
            flashcardViewModel.correctAnswersCount = 0
            flashcardViewModel.currentIndex = 0  // Reset the index
            binding.scoreTextView.visibility = View.GONE // Hide score TextView
            updateQuestion()
            binding.generateButton.isEnabled = false
            binding.submitButton.isEnabled = true
        }


        binding.submitButton.setOnClickListener {
            val userAnswer = binding.answerEditText.text.toString().toIntOrNull()

            // Check if the user's answer is correct and increment the score
            if (userAnswer != null && flashcardViewModel.checkAnswer(userAnswer)) {
                flashcardViewModel.correctAnswersCount++
            }

            //This part is not quite right
            if (flashcardViewModel.currentIndex == 9 && flashcardViewModel.correctAnswersCount <= 9) {
                flashcardViewModel.moveToNext()
                binding.generateButton.isEnabled = true
                binding.submitButton.isEnabled = false

                Toast.makeText(this, "${flashcardViewModel.correctAnswersCount} out of 10", Toast.LENGTH_SHORT).show()
                binding.scoreTextView.text = "${flashcardViewModel.correctAnswersCount} out of 10"
                binding.scoreTextView.visibility = View.VISIBLE
                flashcardViewModel.correctAnswersCount = 0
            } else {
                flashcardViewModel.moveToNext()
                updateQuestion()
            }
        }


    }

    companion object {
        fun newIntent(packageContext: Context, answerIsTrue: Boolean): Intent {
            return Intent(packageContext, FlashcardActivity::class.java).apply {

            }
        }
    }

    private fun updateQuestion(){
        val showText : String = flashcardViewModel.setQuestion()
        binding.questionTextView.text = showText
    }
}